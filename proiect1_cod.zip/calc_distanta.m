function distanta = calc_distanta(p1, p2)
    distanta=sqrt(sum((double(p1)-double(p2)).^2));
    %trebuie sa convertim valorile p1 si p2 in double 
    %pentru a nu obtne alte valori ale distantei
end
