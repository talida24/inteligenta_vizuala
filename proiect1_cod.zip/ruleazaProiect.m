% REALIZAREA IMAGINILOR MOZAIC

%imaginea referinta care va fi transformata in mozaic
params.imgReferinta = imread('C:\Users\Talida\Desktop\HOT Balloon Trip_Ultra HD.jpg');

%directorul de unde se preiau piesele mozaicului
params.numeDirector = ['C:\Users\Talida\Desktop\colectie']

%formatul pieselor de mozaic
params.tipImagine = 'png';

params.numarPieseMozaicOrizontala =100;
params.afiseazaPieseMozaic = 1;

%criteriu alegere metoda creare mozaic
params.criteriu = 'distantaCuloareMedie';

imgMozaic = construiesteMozaic(params);
imwrite(imgMozaic,'mozaic_truck.jpg'); %imaginea mozaic finala
figure, imshow(imgMozaic)