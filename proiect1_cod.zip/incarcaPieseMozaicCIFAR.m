function pieseMozaic = incarcaPieseMozaicCIFAR(params)

progres = waitbar(0, 'Incarcare piese mozaic din setul de date CIFAR...');

%incarca piesele de mozaic din CIFAR
data=load('C:\Users\Talida\Desktop\cifar-10-matlab.tar\cifar-10-matlab\cifar-10-batches-mat\data_batch_3.mat') 
 z=0;
for(i=1:10000)
    if(data.labels(i)==9) 
       z=z+1;
    end
end
[H W C]=size(reshape(data.data(1,:), [32 32 3])); %dimensiunile unei imagini din CIFAR
 pieseMozaic = uint8(zeros(H,W,C,z)); 

    %converteste imaginile din cifar in formatul utilizat in cod
    for(i=1:10000)
    if(data.labels(i)==9) 
       pieseMozaic(:,:,:,i) = reshape(data.data(i,:), [32 32 3]);
    end
        waitbar(i/10000, progres);
    end
close(progres);

end
