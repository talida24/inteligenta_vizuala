function params = calculeazaDimensiuniMozaic(params)
%calculeaza dimensiunile mozaicului
%obtine si imaginea de referinta redimensionata avand aceleasi dimensiuni ca mozaicul


[h, w, c] = size(params.imgReferinta); %dimensiunile imaginii referinta
[H W C]=size(imread('C:\Users\Talida\Desktop\colectie\001.png')) %dimensiunile unei imagini din colectie

%daca vrem sa folosim imaginile din cifar decomentam urmatoarele 2 randuri
%si il comentam pe cel anterios

%  load('C:\Users\Talida\Desktop\cifar-10-matlab.tar\cifar-10-matlab\cifar-10-batches-mat\data_batch_1.mat')
%  [H W C]=size(reshape(data(1,:), [32 32 3]));

%calculeaza automat numarul de piese pe verticala
params.numarPieseMozaicVerticala = ceil((((params.numarPieseMozaicOrizontala*W) *h)/w)/H);
params.imgReferintaRedimensionata = imresize(params.imgReferinta, [H*params.numarPieseMozaicVerticala W*params.numarPieseMozaicOrizontala]);