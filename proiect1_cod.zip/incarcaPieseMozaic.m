function pieseMozaic = incarcaPieseMozaic(params)

%fprintf('Incarcam piesele pentru mozaic din director \n');

%[H W C] dimensiunile pozei mici din colectie
[H W C]=size(imread('C:\Users\Talida\Desktop\colectie\001.png'));
x = dir([params.numeDirector '\*.png']);
pieseMozaic = uint8(zeros(H,W,C,length(x)));

s='\';
progres = waitbar(0, 'Incarcare piese mozaic...');
for i = 1:length(x)
    pieseMozaic(:,:,:,i) = imread(strcat(params.numeDirector,s,x(i).name));
    %pieseMozaic imi retine toate imaginile din directorul colectie
    waitbar(i/length(x), progres);
end
close(progres);

if params.afiseazaPieseMozaic
    %afiseaza primele 100 de piese ale mozaicului
    figure,
    title('Primele 100 de piese ale mozaicului sunt:');
    idxImg = 0;
    for i = 1:10
        for j = 1:10
            idxImg = idxImg + 1;
            subplot(10,10,idxImg);
            imshow(pieseMozaic(:,:,:,idxImg));
        end
    end
    drawnow;
    pause(2);
end
