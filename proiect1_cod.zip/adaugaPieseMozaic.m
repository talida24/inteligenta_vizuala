function imgMozaic = adaugaPieseMozaic(params)

imgMozaic = uint8(zeros(size(params.imgReferintaRedimensionata)));
[H,W,C,N] = size(params.pieseMozaic)
[h,w,c] = size(params.imgReferintaRedimensionata);

switch(params.criteriu)
    case 'aleator'

        nrTotalPiese = params.numarPieseMozaicOrizontala * params.numarPieseMozaicVerticala;
        nrPieseAdaugate = 0;
        progres = waitbar(0, 'Construire mozaic...');
        %verifica daca imaginea este gri sau color
        if(size(params.imgReferintaRedimensionata,3)==1)
         for(k=1:N)
             %daca imaginea referinta este gri atunci toate piesele
             %din colectie vor fi convertite in imagini gri
             params.pieseMozaic(:,:,k)=rgb2gray(params.pieseMozaic(:,:,:,k));
         end
        end
        for i =1:params.numarPieseMozaicVerticala
            for j=1:params.numarPieseMozaicOrizontala
                %alege un indice aleator din cele N
                indice = randi(N);  
                if(size(params.imgReferintaRedimensionata,3)==1)
                    %cazul cand imaginea este gri
                    imgMozaic((i-1)*H+1:i*H,(j-1)*W+1:j*W,:) = params.pieseMozaic(:,:,indice);
                else
                    %cazul cand imaginea este color
                    imgMozaic((i-1)*H+1:i*H,(j-1)*W+1:j*W,:) = params.pieseMozaic(:,:,:,indice);
                end
                nrPieseAdaugate = nrPieseAdaugate+1;
                waitbar(i/params.numarPieseMozaicVerticala, progres);
            end
           close(progres); 
        end
      
    case 'Talida'
        nrTotalPiese = params.numarPieseMozaicOrizontala * params.numarPieseMozaicVerticala;
        nrPieseAdaugate = 0;
        %verifica daca imaginea este gri sau color
        if(size(params.imgReferintaRedimensionata,3)==1)
         %daca imaginea referinta este gri atunci toate piesele
         %din colectie vor fi convertite in imagini gri
         for(k=1:N)
             params.pieseMozaic(:,:,k)=rgb2gray(params.pieseMozaic(:,:,:,k));
         end
        end
        progres = waitbar(0, 'Construire mozaic...');
        for i=1:params.numarPieseMozaicVerticala
            for j=1:params.numarPieseMozaicOrizontala
                medie = mean2(params.imgReferintaRedimensionata((i-1)*H+1:i*H, (j-1)*W+1:j*W,:));
                %calculam media pe o portiune din imaginea referinta
                %corespunzatoare unei imagini din colectie
                distanta_min=100000;
                for k=1:N
                  %verifica care este cea mai apropiata piesa (din punct de
                  %vedere al mediei culorilor) de portiunea din img de referinta
			      if(sqrt(sum(mean2(params.pieseMozaic(:,:,:,k)) - medie).^2) < distanta_min)
                      distanta_min=sqrt(sum(mean2(params.pieseMozaic(:,:,:,k)) - medie).^2);
                      retine=k; %cand s-a gasit o piesa i se retine pozitia
                  end
                end
                %in imaginea mozaic finala se va insera piesa de mozaic
                %gasita ca fiind cea mai apropiata de cea de referinta
                if(size(params.imgReferintaRedimensionata,3)==1)
                    %cazul cand imaginea este gri
                   imgMozaic((i-1)*H+1:i*H,(j-1)*W+1:j*W,:)= params.pieseMozaic(:,:,retine);
                else
                    %cazul cand imaginea este color
                   imgMozaic((i-1)*H+1:i*H,(j-1)*W+1:j*W,:)= params.pieseMozaic(:,:,:,retine);
                   nrPieseAdaugate = nrPieseAdaugate+1;          
                end
            end
            waitbar(i/params.numarPieseMozaicVerticala, progres);
        end
        close(progres);
        
    case 'distantaCulori'
       nrTotalPiese = params.numarPieseMozaicOrizontala * params.numarPieseMozaicVerticala;
       nrPieseAdaugate = 0;
        %verifica daca imaginea referinta este gri sau color; daca este gri
        %atunci toate piesele din colectie vor fi convertite in imagini gri 
       if(size(params.imgReferintaRedimensionata,3)==1)
         for(k=1:N)
             params.pieseMozaic(:,:,k)=rgb2gray(params.pieseMozaic(:,:,:,k));
         end
       end
      progres = waitbar(0, 'Construire mozaic...');
        for i=1:params.numarPieseMozaicVerticala
            for j=1:params.numarPieseMozaicOrizontala
                %REF retine imaginea corespunzatoare unei piese din   
                %imaginea de referinta
                REF=params.imgReferintaRedimensionata((i-1)*H+1:i*H, (j-1)*W+1:j*W,:);
                %transforma matricea REF intr-un vector
                vectorREF = REF(:);
                distanta_min=10000000000;
                
                for k=1:N
                    %verificam daca imaginea este gri sau color si retinem
                    %in PIESA imaginea k din colectie
                    if(size(params.imgReferintaRedimensionata,3)==1)
                        PIESA=params.pieseMozaic(:,:,k);
                    else
                        PIESA=params.pieseMozaic(:,:,:,k);
                    end
                  %transforma matricea PIESA in vector
                  vectorPIESA=PIESA(:);
                  %cautam cea mai mica distanta intre cei doi vectori si
                  %retinem pozitia imaginii
                  if(calc_distanta(vectorPIESA,vectorREF) < distanta_min)
                      distanta_min=calc_distanta(vectorPIESA,vectorREF);
                      retine=k; 
                  end
                end
                %in imaginea mozaic finala se va insera piesa de mozaic
                %gasita ca fiind cea mai apropiata de cea de referinta
                if(size(params.imgReferintaRedimensionata,3)==1)
                   %imagine gri
                   imgMozaic((i-1)*H+1:i*H,(j-1)*W+1:j*W,:)= params.pieseMozaic(:,:,retine);
                else
                   %imagine color
                   imgMozaic((i-1)*H+1:i*H,(j-1)*W+1:j*W,:)= params.pieseMozaic(:,:,:,retine);
                   nrPieseAdaugate = nrPieseAdaugate+1;
                end
            end
              waitbar(i/params.numarPieseMozaicVerticala, progres);
          end	
         close(progres);
        
    case 'distantaCuloareMedie'

       nrTotalPiese = params.numarPieseMozaicOrizontala * params.numarPieseMozaicVerticala;
       nrPieseAdaugate = 0;
       %verifica daca imaginea referinta este gri sau color; daca este gri
       %atunci toate piesele din colectie vor fi convertite in imagini gri 
       if(size(params.imgReferintaRedimensionata,3)==1)
         for(k=1:N)
             params.pieseMozaic(:,:,k)= rgb2gray(params.pieseMozaic(:,:,:,k));
         end
       end
       %in functie de culoarea imaginii vom retine in RGB_piese media pe
       %cele trei canale ale fiecarei imagini din colectie; RGB_piese va
       %avea 3 coloane, cate una pentru fiecare canal
       for i = 1:N
         %imagine gri
         if(size(params.imgReferintaRedimensionata,3)==1)  
           piesa = params.pieseMozaic(:,:,i);
           RGB_piese{i} = mean(reshape(piesa, [], 3));
         else
           %imagine color
           piesa = params.pieseMozaic(:,:,:,i);
           RGB_piese{i} = mean(reshape(piesa, [], 3)); 
         end
       end
        progres = waitbar(0, 'Construire mozaic...');
        for i =1:params.numarPieseMozaicVerticala
            for j=1:params.numarPieseMozaicOrizontala
                %REF retine imaginea corespunzatoare unei piese din   
                %imaginea de referinta
                REF=params.imgReferintaRedimensionata((i-1)*H+1:i*H,(j-1)*W+1:j*W,:);
                %calculeaza media pe canale a imaginii REF
                RGB_img = mean(reshape(REF, [], 3));
                distanta_min=100000;
                for k=1:N
                  %cauta cea mai mica distanta euclidiana intre cele doua
                  %medii (media pe canale e pieselor si media pe canale a
                  %unei portiuni din img referinta corespunzatoare unei
                  %piese
                    distanta_euclidiana = calc_distanta(RGB_piese{k}, RGB_img);
                    if distanta_euclidiana < distanta_min
                         distanta_min=distanta_euclidiana;  
                         retine=k;
                    end
                end
                %in imaginea mozaic finala se va insera piesa de mozaic
                %gasita ca fiind cea mai apropiata de cea de referinta
                         if(size(params.imgReferintaRedimensionata,3)==1)
                           imgMozaic((i-1)*H+1:i*H,(j-1)*W+1:j*W,:)= params.pieseMozaic(:,:,retine);
                         else
                           imgMozaic((i-1)*H+1:i*H,(j-1)*W+1:j*W,:)= params.pieseMozaic(:,:,:,retine);
                         end
                    
                nrPieseAdaugate = nrPieseAdaugate+1;
            end
            waitbar(i/params.numarPieseMozaicVerticala, progres);
         end
close(progres);

    otherwise
        printf('EROARE, optiune necunoscut \n');
    
end
    
    
    
    
    
