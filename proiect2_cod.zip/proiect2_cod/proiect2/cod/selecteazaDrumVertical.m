function d = selecteazaDrumVertical(E,metodaSelectareDrum)

%selecteaza drumul vertical ce minimizeaza functia cost calculate pe baza lui E
%input: E - energia la fiecare pixel calculata pe baza gradientului
%       metodaSelectareDrum - specifica metoda aleasa pentru selectarea drumului. Valori posibile:
%                           'aleator' - alege un drum aleator
%                           'greedy' - alege un drum utilizand metoda Greedy
%                           'programreDinamica' - alege un drum folosind metoda Programare Dinamica
% output: d - drumul vertical ales

d = zeros(size(E,1),2);

switch metodaSelectareDrum
    case 'aleator'
        
        %pentru linia 1 alegem primul pixel in mod aleator
        linia = 1;
        %coloana o alegem intre 1 si size(E,2)
        coloana = randi(size(E,2));
        %punem in d linia si coloana coresponzatoare pixelului
        d(1,:) = [linia coloana];
        for i = 2:size(d,1)
            %alege urmatorul pixel pe baza vecinilor
            %linia este i
            linia = i;
            %coloana depinde de coloana pixelului anterior
            if d(i-1,2) == 1%pixelul este localizat la marginea din stanga
                %doua optiuni
                optiune = randi(2)-1;%genereaza 0 sau 1 cu probabilitati egale
            elseif d(i-1,2) == size(E,2)%pixelul este la marginea din dreapta
                %doua optiuni
                optiune = randi(2) - 2; %genereaza -1 sau 0
            else
                optiune = randi(3)-2; % genereaza -1, 0 sau 1
            end
            coloana = d(i-1,2) + optiune;%adun -1 sau 0 sau 1:
            % merg la stanga, dreapta sau stau pe loc
            d(i,:) = [linia coloana];
        end
        
    case 'greedy'  
        
        %pornim de la prima linie
        linia = 1;
        %gasim minimul de pe prima coloana si retinem pozitia coloanei
        [val coloana]= min(E(1,:));
        
        %var2 de gasire a minimului
%         coloana=find(E(linia,:)==min(E(linia,:)));
%         if length(coloana)>1
%             minim_ales=randi(length(coloana));
%             coloana=coloana(minim_ales);
%         end
%         

        %punem in d linia si coloana coresponzatoare pixelului
        d(1,:) = [linia coloana];
        for i = 2:size(d,1)
            %alege urmatorul pixel pe baza vecinilor
            linia = i;
            %coloana depinde de coloana pixelului anterior
            if d(i-1,2) == 1%pixelul este localizat la marginea din stanga
                optiuni=[E(i,1) E(i,2)];
                [val coloana]=min(optiuni);
                
            elseif d(i-1,2) == size(E,2)%pixelul este la marginea din dreapta
                optiuni=[E(i,size(E,2)-1) E(i, size(E,2))]
                [val poz_coloana]=min(optiuni);
                if poz_coloana==1 coloana=coloana-1;
                end
                
            else
            %valorile pentru coloana:
            % daca in vectorul optiuni minimul este pe pozitia 1, mergem in stanga jos (coloana=coloana-1)
            % daca in vectorul optiuni minimul este pe pozitia 2 coloana nu se modifica
            % daca in vectorul optiuni minimul este pe pozitia 3, mergem in dreapta jos (coloana=coloana+1)
            
                optiuni=[E(i,coloana-1) E(i,coloana) E(i,coloana+1)];
                [val poz_coloana]=min(optiuni);
                if poz_coloana==1 coloana=coloana-1;
                elseif poz_coloana==3 coloana=coloana+1;
                end
            end
            
            d(i,:) = [linia coloana];
        end
            
    case 'programareDinamica'
        
        %construim matricea de costuri
        for i = 2: size(E,1)
            for j = 1:size(E,2)
                if j == 1
                    E(i,j) = E(i,j) + min(E(i-1,1:2));
                elseif j == size(E,2)
                    E(i,j) = E(i,j) + min(E(i-1,size(E,2)-1:size(E,2)));
                else
                    E(i,j) = E(i,j) + min(E(i-1,j-1:j+1));
                end
            end
        end
        

        
       linia=size(E,1); 
       %gasim minimul de pe ultima coloana si retinem pozitia coloanei
       coloana=find(E(linia,:)==min(E(linia,:)));
       %daca avem mai multe pozitii unde se regaseste minimul atunci il alegem random
       if length(coloana)>1
           minim_ales=randi(length(coloana));
           coloana=coloana(minim_ales);
       end
       
       %punem in d linia si coloana coresponzatoare pixelului
       d(linia,:)=[linia coloana];

        %vom urca in matricea de costuri pana ajungem la linia 1
        for i=size(E,1)-1:-1:1
            linia=i;
            if d(i+1,2)==1
                optiune=[E(i,coloana), E(i,coloana+1)];
                pozitie_coloana=find(optiune==min(optiune));
            elseif d(i+1,2)==size(E,2)
                    optiune = [E(i,coloana-1),E(i,coloana)];
                    pozitie_coloana=coloana+find(optiune==min(optiune))-2;
            else
            %valorile pentru pozitie_coloana:
            % daca in vectorul optiune minimul este pe pozitia 1, mergem in stanga jos (coloana+1-2=coloana-1)
            % daca in vectorul optiune minimul este pe pozitia 2, mergem in jos pe aceeasi coloana(coloana+2-2=coloana)
            % daca in vectorul optiune minimul este pe pozitia 3, mergem in dreapta jos (coloana+3-2=coloana+1)
            
                    optiune=[E(i,coloana-1), E(i,coloana), E(i,coloana+1)];
                    pozitie_coloana=coloana+find(optiune==min(optiune))-2;
            end
            
            %daca avem mai multe pozitii unde se regaseste minimul atunci il alegem random
            if length(pozitie_coloana) > 1
                minim_ales = randi(length(pozitie_coloana));
                pozitie_coloana = pozitie_coloana(minim_ales);
            end
            
            d(i,:)=[linia pozitie_coloana];
            coloana=pozitie_coloana;
        end
        
    otherwise
        error('Optiune pentru metodaSelectareDrum invalida');
end

end