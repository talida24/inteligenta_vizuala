function d = selecteazaDrumOrizontal(E,metodaSelectareDrum)

%selecteaza drumul Orizontal ce minimizeaza functia cost calculate pe baza lui E
%input: E - energia la fiecare pixel calculata pe baza gradientului
%       metodaSelectareDrum - specifica metoda aleasa pentru selectarea drumului. Valori posibile:
%                           'aleator' - alege un drum aleator
%                           'greedy' - alege un drum utilizand metoda Greedy
%                           'programreDinamica' - alege un drum folosind metoda Programare Dinamica
% output: d - drumul orizontal ales
d = zeros(size(E,2),2);

switch metodaSelectareDrum
    case 'aleator'
        %pentru coloana 1 alegem primul pixel in mod aleator
        coloana = 1;
        %linia o alegem intre 1 si size(E,1)
        linia = randi(size(E,1));
        %punem in d linia si coloana coresponzatoare pixelului
        d(1,:) = [linia coloana];
        for j = 2:size(d,1)
            %alege urmatorul pixel pe baza vecinilor
            %coloana este j
            coloana =j;
            %linia depinde de linia pixelului anterior
            if d(j-1,1) == 1%pixelul este localizat la marginea de sus
                %doua optiuni
                optiune = randi(2)-1;%genereaza 0 sau 1 cu probabilitati egale 
            elseif d(j-1,1) == size(E,1)%pixelul este la marginea de jos
                %am doua optiuni
                optiune = randi(2) - 2; %genereaza -1 sau 0
            else
                optiune = randi(3)-2; % genereaza -1, 0 sau 1
            end
            linia = d(j-1,1) + optiune;%adun -1 sau 0 sau 1: 
                                         % merg la stanga, dreapta sau stau pe loc
            d(j,:) = [linia coloana];
        end
    case 'greedy'      
        
        coloana = 1;
        %alegem linia cu cel mai mic element de pe prima coloana
        linia =find(E(:,coloana)==min(E(:,coloana)));
        %daca sunt mai multe linii care au valoarea minima
        if length(linia) > 1
            minim_ales = randi(length(linia));
            linia = linia(minim_ales);
        end
        
        %var2 alegere minim
        %         linia =find(E(:,1)==min(E(:,1)));
        %         %daca sunt mai multe linii care au valoarea minima
        %         if length(linia) > 1
        %             minim_ales = randi(length(linia));
        %             linia = linia(minim_ales);
        %         end
        
        d(1,:) = [linia coloana];
        for j = 2:size(d,1)
            %alege urmatorul pixel pe baza vecinilor
            %coloana este j
            coloana = j;
            %linia depinde de linia pixelului anterior
            if d(j-1,1) == 1%pixelul este localizat la marginea de de sus
                optiuni=[E(1,j) E(2,j)];
                [val coloana]=min(optiuni);
                
            elseif d(j-1,1) == size(E,1)%pixelul este la marginea de jos
                optiuni=[E(size(E,1)-1,j) E(size(E,1),j)]
                [val poz_linie]=min(optiuni);
                if poz_linie==1 linia=linia-1;
                end
                
            else
            %valorile pentru linia:
            % daca in vectorul optiuni minimul este pe pozitia 1, mergem in stanga jos (linia=linia-1)
            % daca in vectorul optiuni minimul este pe pozitia 2 linia nu se modifica
            % daca in vectorul optiuni minimul este pe pozitia 3, mergem in dreapta jos (linia=linia+1)
            
                optiuni=[E(linia-1,j) E(linia,j) E(linia+1,j)];
                [val poz_linia]=min(optiuni);
                if poz_linia==1 linia=linia-1;
                elseif poz_linia==3 linia=linia+1;
                end
                
            end
            
            d(j,:) = [linia coloana];
        end
        
    case 'programareDinamica'
        
        %construim matricea de costuri
        for  j = 2:size(E,2)
           for i = 1: size(E,1)           
               if i == 1
                   E(i,j) = E(i,j) + min(E(1:2,j-1));
               elseif i == size(E,1)
                   E(i,j) = E(i,j) + min(E(size(E,1)-1:size(E,1),j-1));
               else
                  E(i,j) = E(i,j) + min(E(i-1:i+1,j-1)); 
               end            
           end
        end
        
        coloana = size(E,2);
        %gasim minimul de pe ultima linie si retinem pozitia liniei
        linia =find(E(:,coloana)==min(E(:,coloana)));
        %daca avem mai multe pozitii unde se regaseste minimul atunci il alegem random
        if length(linia) > 1
            minim_ales = randi(length(linia));
            linia = linia(minim_ales);
        end
        
        %punem in d linia si coloana coresponzatoare pixelului
        d(coloana,:) = [linia coloana];
        
        for j = size(E,2)-1:-1:1
            %alege urmatorul pixel pe baza vecinilor
            %coloana este j
            coloana = j;
            %coloana depinde de coloana pixelului anterior
            if d(j+1,1) == 1%pixelul este localizat la marginea de sus
                optiune=[E(1,j),E(2,j)];
                pozitie_linie = find(optiune==min(optiune));
            elseif d(j+1,1) == size(E,1)%pixelul este la marginea de jos
                optiune=[E(size(E,1)-1,j),E(size(E,1),j)];
                pozitie_linie = linia + find(optiune==min(optiune)) -2;

            else
            %valorile pentru pozitie_linie:
            % daca in vectorul optiune minimul este pe pozitia 1, mergem in stanga jos (linia+1-2=linia-1)
            % daca in vectorul optiune minimul este pe pozitia 2, mergem in jos pe aceeasi linia(linia+2-2=linia)
            % daca in vectorul optiune minimul este pe pozitia 3, mergem in dreapta jos (linia+3-2=linia+1)
            
                optiune=[E(linia-1,j),E(linia,j), E(linia+1,j)];
                pozitie_linie = linia + find(optiune==min(optiune)) -2;

            end
            
             %daca avem mai multe pozitii unde se regaseste minimul atunci il alegem random
            if length(linia) > 1
                minim_ales = randi(length(linia));
                linia = linia(minim_ales);
            end
            
            d(j,:) = [linia coloana];
        end
        
    otherwise
        error('Optiune pentru metodaSelectareDrum invalida');
end
end