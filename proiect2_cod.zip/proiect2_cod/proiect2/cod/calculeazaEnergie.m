function E = calculeazaEnergie(img)
%calculeaza energia la fiecare pixel pe baza gradientului
%input: img - imaginea initiala
%output: E - energia

%transforma imaginea
img = rgb2gray(img);
%foloseste filtrul sobel
f = -fspecial('sobel');
Gx = imfilter(int16(img),f');                               
Gy = imfilter(int16(img),f);
%calzularea magnitudinii
E = sqrt(double(Gx.^2+Gy.^2));