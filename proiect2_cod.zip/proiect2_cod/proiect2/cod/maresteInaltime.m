function img = maresteInaltime(img,numarPixeliInaltime,metodaSelectareDrum,ploteazaDrum,culoareDrum)

E = calculeazaEnergie(img);

for i = 1:numarPixeliInaltime
    
    disp(['Adauga drumul vertical numarul ' num2str(i) ...
        ' dintr-un total de ' num2str(numarPixeliInaltime)]);
    
    %alege drumul vertical care conecteaza dreapta-stanga
    drum = selecteazaDrumOrizontal(E,metodaSelectareDrum);
    
    %drumul gasit va fi facut alb
    for j = 1:size(drum,1)
        E(drum(j,1),drum(j,2),:) = 255;
    end
    
    %adaugam drumul gasit in matricea E
    E = adaugaDrumOrizontal(E,drum);
                
    %afiseaza drum
%     if ploteazaDrum
%         ploteazaDrumOrizontal(img,E,drum,culoareDrum);
%         pause(1);
%         close(gcf);
%     end
    
    %adaugam drumul in imagine
    img = adaugaDrumOrizontal(img,drum);
    
end
