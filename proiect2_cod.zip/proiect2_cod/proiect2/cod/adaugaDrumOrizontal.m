function img1 = adaugaDrumOrizontal(img,drum)
%adauga drumul orizontal din imagine
%input: img - imaginea initiala
%       drum - drumul vertical
%output img1 - imaginea initiala in care s-a adaugat drumul orizontal

img1 = zeros(size(img,1)+1,size(img,2),size(img,3),'uint8');
[H W C]=size(img);
[h w c]=size(img1);

for i=1:size(img1,2)
        linia = drum(i,1);
        %copiem partea de sus
        img1(1:linia,i,:) = img(1:linia,i,:);
        %duplicam coloana
        img1(linia+1,i,:) = img(linia,i,:);
        %copiem partea de jos
        img1(linia+2:h,i,:) = img(linia+1:H,i,:);
end