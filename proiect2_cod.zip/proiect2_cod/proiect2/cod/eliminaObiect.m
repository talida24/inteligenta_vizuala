function imagineReturnata = eliminaObiect(img_decupata,metodaSelectareDrum,...
                                     ploteazaDrum,culoareDrum)

figure,imshow(img_decupata);
decupare = getrect; 
latime=ceil(decupare(3));
inaltime=ceil(decupare(4));
x_colt=ceil(decupare(1));
y_colt=ceil(decupare(2));

if latime>inaltime
    
        numarPixeliInaltime=inaltime;
        for i = 1:numarPixeliInaltime+1
            
        disp ('Asteptati...');
        
        E = calculeazaEnergie(img_decupata);
        %in dreptunghiul selectat facem valorile energiilor foarte mici;
        %avand energiile foarte mici, drumurile vor fi cautate doar in acest chenar
        E(y_colt:y_colt+inaltime,x_colt:x_colt+latime,:)=-99999999999999999999;
        inaltime=inaltime-1;
        %alege drumul vertical care conecteaza sus de jos
        drum = selecteazaDrumOrizontal(E,metodaSelectareDrum);
        
        %         afiseaza drum
%                     if ploteazaDrum
%                         ploteazaDrumOrizontal(img_decupata,E,drum,culoareDrum);
%                         pause(1);
%                         close(gcf);
%                     end
%          
        %elimina drumul din imagine
        img_decupata = eliminaDrumOrizontal(img_decupata,drum);

        end
    
else

    numarPixeliLatime=latime;
    for i = 1:numarPixeliLatime+1
        
        disp ('Asteptati...');
        
        E = calculeazaEnergie(img_decupata);
        %in dreptunghiul selectat facem valorile energiilor foarte mici;
        %avand energiile foarte mici, drumurile vor fi cautate doar in acest chenar
        E(y_colt:y_colt+inaltime,x_colt:x_colt+latime,:)=-99999999999999999;
        latime=latime-1;
        %alege drumul vertical care conecteaza sus de jos
        drum = selecteazaDrumVertical(E,metodaSelectareDrum);
        
        %         afiseaza drum
%                     if ploteazaDrum
%                         ploteazaDrumVertical(img_decupata,E,drum,culoareDrum);
%                         pause(1);
%                         close(gcf);
%                     end
        
        %elimina drumul din imagine
        img_decupata = eliminaDrumVertical(img_decupata,drum);

    end

end
imagineReturnata =img_decupata;


