function img = micsoreazaInaltime(img,numarPixeliInaltime,metodaSelectareDrum,ploteazaDrum,culoareDrum)


for i = 1:numarPixeliInaltime
    
    disp(['Eliminam drumul Orizontal numarul ' num2str(i) ...
        ' dintr-un total de ' num2str(numarPixeliInaltime)]);
    
    %calculeaza energia dupa ecuatia (1) din articol
    E = calculeazaEnergie(img);
    
    %alege drumul vertical care conecteaza sus de jos
    drum = selecteazaDrumOrizontal(E,metodaSelectareDrum);
    
    %afiseaza drum
%     if ploteazaDrum
%         ploteazaDrumOrizontal(img,E,drum,culoareDrum);
%         pause(1);
%         close(gcf);
%     end
    
    %elimina drumul din imagine
    img = eliminaDrumOrizontal(img,drum);

end