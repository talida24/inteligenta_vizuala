function img = maresteLatime(img,numarPixeliLatime,metodaSelectareDrum,ploteazaDrum,culoareDrum)

E = calculeazaEnergie(img);

for i = 1:numarPixeliLatime
    
    disp(['Adauga drumul vertical numarul ' num2str(i) ...
        ' dintr-un total de ' num2str(numarPixeliLatime)]);
       
    %alege drumul vertical care conecteaza sus de jos
    drum = selecteazaDrumVertical(E,metodaSelectareDrum);
    
    %drumul gasit va fi facut alb
    for j = 1:size(drum,1)
        E(drum(j,1),drum(j,2),:) = 255;
    end
    
    %adaugam drumul gasit in matricea E
    E = adaugaDrumVertical(E,drum);
                
    %afiseaza drum
%     if ploteazaDrum
%         ploteazaDrumVertical(img,E,drum,culoareDrum);
%         pause(1);
%         close(gcf);
%     end
    
    %adaugam drumul in imagine
    img = adaugaDrumVertical(img,drum);
    
end
