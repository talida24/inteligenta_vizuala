function descriptoriExempleNegative = obtineDescriptoriExempleNegative(parametri)
% descriptoriExempleNegative = matrice MxD, unde:
%   M = numarul de exemple negative de antrenare (NU sunt fete de oameni),
%   M = parametri.numarExempleNegative
%   D = numarul de dimensiuni al descriptorului
%   in mod implicit D = (parametri.dimensiuneFereastra/parametri.dimensiuneCelula)^2*parametri.dimensiuneDescriptorCelula

imgFiles = dir( fullfile( parametri.numeDirectorExempleNegative , '*.jpg' ));
numarImagini = length(imgFiles);

numarExempleNegative_pe_imagine = ceil(parametri.numarExempleNegative/numarImagini);
descriptoriExempleNegative = zeros(numarExempleNegative_pe_imagine*numarImagini,(parametri.dimensiuneFereastra/parametri.dimensiuneCelulaHOG)^2*parametri.dimensiuneDescriptorCelula);

disp(['Exista un numar de imagini = ' num2str(numarImagini) ' ce contine numai exemple negative']);
    linie=0;
for idx = 1:numarImagini
    disp(['Procesam imaginea numarul ' num2str(idx)]);
    img = imread([parametri.numeDirectorExempleNegative '/' imgFiles(idx).name]);
    if size(img,3) == 3
        img = rgb2gray(img);
    end 

    %completati codul functiei in continuare
    for j=1:numarExempleNegative_pe_imagine
        %extragem din imaginea mare o fereastra care sa se potriveasca cu
        %"piesele" pe care le avem noi in ExemplePozitive
        xMin=randi(size(img,2)-parametri.dimensiuneFereastra+1);
        yMin=randi(size(img,1)-parametri.dimensiuneFereastra+1);
        xMax=xMin+parametri.dimensiuneFereastra-1;
        yMax=yMin+parametri.dimensiuneFereastra-1;
        imgFereastra=img(yMin:yMax,xMin:xMax);
        celuleHOG=vl_hog(single(imgFereastra), parametri.dimensiuneCelulaHOG);
        descriptorHOG=reshape(celuleHOG,[1 (parametri.dimensiuneFereastra/parametri.dimensiuneCelulaHOG)^2 * parametri.dimensiuneDescriptorCelula]);
        linie=linie+1;
        descriptoriExempleNegative(linie,:)=descriptorHOG;
    end
       
    
end